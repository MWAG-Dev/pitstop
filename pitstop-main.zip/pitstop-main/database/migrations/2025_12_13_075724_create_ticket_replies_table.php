<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ticket_replies', function (Blueprint $table) {
    		$table->id();

    		$table->foreignId('ticket_id')
          		->constrained()
          		->cascadeOnDelete();

    		$table->string('author_role')->default('ops');
    		$table->string('author_email')->nullable();
    		$table->text('message');

    		$table->timestamps();
	});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ticket_replies');
    }
};
